#!/usr/bin/env bash
set -e
echo "Ensure you edited .env with secrets (copy from .env.sample)"
if [ ! -f .env ]; then
  cp .env.sample .env
  echo ".env created from sample. Please edit and re-run."
  exit 1
fi
docker-compose build --no-cache
docker-compose up -d
echo "All services started. Phoenix on http://localhost:4000, Python worker on http://localhost:9000"
