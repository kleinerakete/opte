#!/bin/bash
echo 'Running PUZSCAN...'
