#!/usr/bin/env bash
node server_node.js ${1:-8443}
