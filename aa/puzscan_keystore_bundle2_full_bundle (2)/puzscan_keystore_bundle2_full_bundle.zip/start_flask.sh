#!/usr/bin/env bash
python3 app_flask.py ${1:-8443}
